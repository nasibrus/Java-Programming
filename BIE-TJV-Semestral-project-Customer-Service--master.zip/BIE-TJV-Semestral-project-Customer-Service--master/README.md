# VaadinApp
BIE-TJV Semester Work 
This is My Semester Project from BIE-TJV(Java Technologies Course) 
<p><strong>Nasibov Ruslan</strong></p>
<p><strong>Prague,Czech Republic 2020</strong></p>
<p><strong>Student of Czech Technical University In Prague(Faculty Of Information)</strong></p>
 
# About Project
This project is a customer form in web app.We can add just name, surname, date of birth and email adress for them.Project created on maven and it is using VaadinApp framework.

# What is Vaadin?
Vaadin is Full stack framework for building web apps in Java.Also Vaadin is an open source web framework that helps Java developers build great user experiences with minimal effort
<p><strong>UI in Java:</strong></p>
<p>Vaadin is the only framework that allows you to write UI 100% in Java without getting bogged down in JS, HTML, and CSS. If you prefer, you can also create layouts in HTML or with a visual designer. Vaadin apps run on the server and handle all communication automatically and securely. Building on the strong Java ecosystem, Vaadin works with your favorite IDEs, tools, and libraries.</p>

# How we run project?
We can run our project with the command <strong>~>mvn jetty:run</strong>
Click on localhost:/8080 and google chrome ask you to download BookStore extension (It is directly runs your vaadin web app in localhost:/8080) and you can make this axtension on your desktop.
![Annotation 2020-05-02 184227](https://user-images.githubusercontent.com/44650808/80870202-45659880-8ca5-11ea-9ec9-7114d46f32c6.png)
![Annotation 2020-05-02 184141](https://user-images.githubusercontent.com/44650808/80870205-45fe2f00-8ca5-11ea-87a0-75474a310f49.png)
![Screenshot (388)](https://user-images.githubusercontent.com/44650808/80870213-50202d80-8ca5-11ea-88ef-8bfc4b12f88c.png)
![Screenshot (389)](https://user-images.githubusercontent.com/44650808/80870214-50b8c400-8ca5-11ea-914b-5f4b9f4dd718.png)
![Screenshot (390)](https://user-images.githubusercontent.com/44650808/80870216-51515a80-8ca5-11ea-9d50-b01d172b5d04.png)
![Screenshot (391)](https://user-images.githubusercontent.com/44650808/80870217-51515a80-8ca5-11ea-848f-63a5c96a3cc5.png)
![Screenshot (392)](https://user-images.githubusercontent.com/44650808/80870218-51515a80-8ca5-11ea-8d36-c5cabe2c8bfc.png)
![Screenshot (393)](https://user-images.githubusercontent.com/44650808/80870219-51e9f100-8ca5-11ea-9a2a-6e72ac8f56ca.png)
![Screenshot (394)](https://user-images.githubusercontent.com/44650808/80870220-51e9f100-8ca5-11ea-91d2-4e4ef655d4a4.png)
